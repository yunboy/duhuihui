package com.JUtils.word;

import java.util.Vector;

/**
 * @desc:word导入工具类<br>
 * 		需要对Word中的图片、样式、文字、表格进行处理，同时由于POI对Word的处理能力有限，所以采用Jadoc处理
 * 
 * @Author:chenssy
 * @date:2014年8月10日
 */
public class WordExportUtils {
	Vector[] vector = new Vector[10];
	
	String[] strings = new String[10];
}
